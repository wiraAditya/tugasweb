var app=angular.module("simanis",["ngRoute","ngCookies"]);
